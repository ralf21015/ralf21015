package com.example.apitry

import android.widget.EditText
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.view.*
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path

interface ApiService
{

    @GET("/api/v2/berry/cheri")
    //@GET("api/v2/berry/{pokemon}")
    //fun findPokemon(@Path("pokemon") pok:String):Call<Request>
    //в общем, хотел сделать поиск по названию ягоды, но почему-то доломал и перестала запускаться, поэтому сделал так, хотя бы показать, что умею данные получать))
    fun getRequest():Call<Request>
    companion object Factory {
        fun create(): ApiService {
            val retrofit = Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl("https://pokeapi.co/")
                .build()

            return retrofit.create(ApiService::class.java);
        }
    }
}