package com.example.apitry

import android.content.Context
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        button.setOnClickListener {
            val sPref = getPreferences(Context.MODE_PRIVATE)
            val savedText = sPref.getString("factor", "")
            if (savedText!="")
            {
                result.text = savedText
            }
            else
            {
            val retrofit = ApiService.create()
            val service = retrofit.getRequest()
            service.enqueue(object : Callback<Request> {
                override fun onResponse(call: Call<Request>, response: Response<Request>) {
                    val m = response.body()
                    result.text = m?.name
                    val ed = sPref.edit()
                    ed.putString("factor", "${result.text}")
                    ed.apply()
                }

                override fun onFailure(call: Call<Request>, t: Throwable) {
                    result.text = "что-то не так"
                }
            })
        }
        }
    }

    override fun onResume() {
        super.onResume()
        val sPref = getPreferences(Context.MODE_PRIVATE)
        val savedText = sPref.getString("factor", "")
        if (savedText!="")
        {
            result.text = savedText
        }
    }
}
