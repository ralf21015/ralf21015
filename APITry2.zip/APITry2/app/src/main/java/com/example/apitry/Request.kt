package com.example.apitry

data class Request (
    val name:String

)